import java.util.Scanner;

public class Main {
    //queen==true and empty==false
    public static void main(String[] args) {
        System.out.print("Please enter the number of queens in the board : ");
        Scanner scanner =new Scanner(System.in);
        int n =scanner.nextInt();
        boolean[][] board =new boolean[n][n];
        for (int i = 0; i <board.length ; i++) {
            for (int j = 0; j <board[i].length ; j++) {
                board[i][j]=false;
            }
        }
        int[] queenPositions=new int[n];
        for (int i = 0; i <queenPositions.length ; i++) {
            queenPositions[i]=-1;
        }
        for (int i = 0; i>=0 && i <board.length ; i++) {
            for (int k = 0; k <board[i].length ; k++) {
                board[i][k]=false;
            }
            int j;
            for (j = queenPositions[i]+1; j <board[i].length ; j++) {
                if(isSafe(i,j,board))
                {board[i][j]=true;
                    break;
                }
            }
            queenPositions[i]=j;
            if (queenPositions[i]==board[i].length)
            {//backtrack to previous row
                queenPositions[i]=-1;
                i=i-2;//take us to last row
            }
        }
        printResult(board);
    }
    public static void printResult(boolean[][] booleans){
        for (int i = 0; i <booleans.length ; i++) {
            for (int j = 0; j <booleans[i].length ; j++) {
                if (booleans[i][j])
                    System.out.print("[*]");
                else
                    System.out.print("[ ]");
            }
            System.out.println();
        }

    }

    public static boolean isSafe(int i, int j,boolean[][] board){
        for (int k = 0; k <board.length ; k++) {
            if (board[k][j])
                return false;
        }
        for (int k = 0; k <board[i].length ; k++) {
            if (board[i][k])
                return false;
        }
        for (int k = 0; k <board.length ; k++) {
            for (int l = 0; l <board[k].length ; l++) {
                if (((k-i)==(l-j) || ((k+l)==i+j) ) && board[k][l])
                    return false;
            }
        }
        return true;
    }

}
